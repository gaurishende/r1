import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './bdemo.html',
  
})
export class BindingComponent implements OnInit {

name=null;
email1=null;
number=null;
city=null;
country=null;
 myColor={'color':'black', 'background-color':'white'};
ChangeColor(){
  this.myColor.color='blue';
  this.myColor["background-color"]='cyan'
}

  constructor() { }

  ngOnInit(): void {
  } 

}
