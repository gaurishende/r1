import {Component} from '@angular/core'
@Component({
selector : 'childDemo',
templateUrl: 'childDemohtml.html'
})

export class ChildComponent{
  data:String;
  temp;
    getValue(event){
      this.temp=event;
    }
    setInputVal(){
      this.data=this.temp.target.value;
    }
}