
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { parentModule } from './parent/parentModule';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';



platformBrowserDynamic().bootstrapModule(parentModule)
  .catch(err => console.error(err));
