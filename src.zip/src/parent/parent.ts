import {Component} from '@angular/core'
@Component({
selector : 'parentdemo',
templateUrl: 'parenthtmldemo.html'
})
export class ParentComponent{
}